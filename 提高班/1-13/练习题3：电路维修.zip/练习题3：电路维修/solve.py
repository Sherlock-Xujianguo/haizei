#!/usr/bin/env python
# coding=utf-8

from random import randint

arr = input().split()
n, m = int(arr[0]), int(arr[1])

print(n, m)

for i in range(n - 1):
    for j in range(m - 1):
        rd = randint(1,100)
        if (rd % 2 == 0):
            print("\\", end="")
        else:
            print("/", end="")
    print("")
