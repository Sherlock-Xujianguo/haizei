/*************************************************************************
	> File Name: std.cpp
	> Author: hug
	> Mail:   hug@haizeix.com
	> Created Time: Sat Dec  8 22:00:18 2018
 ************************************************************************/

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>
#include <cmath>
using namespace std;
int main() {
    return 0;
}
