#!/usr/bin/env python
# coding=utf-8

print("500000")

for i in range(500000):
    print(str(i+1) + " ", end='')
print('')
